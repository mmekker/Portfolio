package com.mygdx.pathfinding;

import java.util.ArrayList;
import java.util.Scanner;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;

public class Grid {
	public Tile grid[][];
	int xLen;
	int yLen;
	int startX;
	int startY;
	int endX;
	int endY;
	Tile startTile;
	Tile endTile;
	public int Xmargin = 0;
	public int Ymargin = 30;
	public static int tileSize = 25;
	private ArrayList<Tile> open;
	private ArrayList<Tile> closed;
	
	public Grid(String fileName)
	{
		produceGrid(Gdx.files.internal(fileName + ".grid"));
	}
	
	public Grid(int xL, int yL)
	{
		startX = 0;
		startY = 0;
		endX = 0;
		endY = 0;
		xLen = xL;
		yLen = yL;
		grid = new Tile[xLen][yLen];
		open = new ArrayList<Tile>();
		closed = new ArrayList<Tile>();
		for(int x = 0; x < xLen; x++)
		{
			for(int y = 0; y < yLen; y++)
			{
				int temp = (int)(Math.random()*12 -2);
				String sTemp = "";
				if(temp == -1)sTemp = "F";
				else sTemp = "" + temp;
				grid[x][y] = new Tile(sTemp,x,y);
			}
		}
		grid[0][0].setWeight("0");
		grid[0][1].setWeight("0");
		grid[1][0].setWeight("F");
		grid[1][1].setWeight("0");
		startTile = grid[startX][startY];
		endTile = grid[endX][endY];
	}
	
	private void produceGrid(FileHandle file)
	{
		String s = file.readString();
		int Xcount = 0;
		int Ycount = 0;
		for(int x = 0; x < s.length(); x++)
		{
			if(s.charAt(x) == '\n')
			{
				xLen = Xcount;
				Xcount = 0;
				Ycount++;
			}
			else if(!(s.charAt(x) == '\r') && !(s.charAt(x) == '\n') && !(s.charAt(x) == ' '))
			{
				Xcount++;
			}
			if(s.charAt(x) == 'T')
				Xcount--;
			
		}
		Ycount++;
		yLen = Ycount;
		grid = new Tile[xLen][yLen];
		String str = file.readString();
		Scanner scan = new Scanner(str);
		for(int y = yLen-1; y >= 0; y--)
		{
			for(int x = 0; x < xLen; x++)
			{
				String sTemp = scan.next();
				grid[x][y] = new Tile(sTemp, x, y);
				if(sTemp.startsWith("T") || sTemp.startsWith("t"))
					grid[x][y].isTele = true;
			}
		}
		scan.close();
		startX = 0;
		startY = 0;
		endX = 0;
		endY = 0;
		open = new ArrayList<Tile>();
		closed = new ArrayList<Tile>();
		startTile = grid[startX][startY];
		endTile = grid[endX][endY];
		findTele();
	}
	private void findTele()
	{
		for(int x = 0; x < xLen; x++)
		{
			for(int y = 0; y < yLen; y++)
			{
				if(grid[x][y].isTele)
				{
					Tile start = grid[x][y];
					for(int x2 = 0; x2 < xLen; x2++)
					{
						for(int y2 = 0; y2 < yLen; y2++)
						{
							if(grid[x2][y2].getWeight().equals(start.getWeight()) && !grid[x2][y2].equals(start))
							{
								start.dest = grid[x2][y2];
								grid[x2][y2].dest = start;
							}
						}
					}
				}
			}
		}
	}
	public void draw(ShapeRenderer sr, SpriteBatch batch, BitmapFont font)
	{
		//Grid
		for(int x = 0; x < xLen; x++)
		{
			for(int y = 0; y < yLen; y++)
			{
				//Grid outline
				/*sr.begin(ShapeType.Line);
				sr.setColor(Color.BLACK);
				sr.rect(x+(tileSize*x) + Xmargin, y+(tileSize*y) + Ymargin, tileSize, tileSize);
				sr.end();*/
				
				sr.begin(ShapeType.Filled);
				if(x == startX && y == startY)
					sr.setColor(Color.GREEN);
				else if(x == endX && y == endY)
					sr.setColor(Color.BLUE);
				else if(grid[x][y].getWeight().equals("F"))
					sr.setColor(Color.RED);
				else
					sr.setColor(Color.TAN);
				int xPos = x+(tileSize*x) + Xmargin;
				int yPos = y+(tileSize*y) + Ymargin;
				if(xPos >= -20 && xPos <= 600
						&& yPos >= -20 && yPos <= 600)
					sr.rect(xPos, yPos, tileSize, tileSize);
				sr.end();
				
				batch.begin();
				font.setColor(Color.BLACK);
				int xOffset = 3;
				if(grid[x][y].isTele)
					xOffset = 0;
				xPos = x+(tileSize*x) + xOffset + Xmargin;
				yPos = y+(tileSize*y) - 2 + tileSize + Ymargin;
				if(xPos >= -20 && xPos <= 600
						&& yPos >= -20 && yPos <= 600)
					font.draw(batch, grid[x][y].getWeight(), xPos, yPos);
				batch.end();
			}
		}
	}

	//TODO: Make it work with android
	
	
	public void findPath(ShapeRenderer sr, SpriteBatch batch, BitmapFont font)
	{
		if(endTile.equals(startTile))
		{
			endTile.parent = startTile;
			return;
		}
		Tile current;
		startTile = grid[startX][startY];
		startTile.g_cost = 0;
		startTile.f_cost = startTile.g_cost;
		open = new ArrayList<Tile>();
		closed = new ArrayList<Tile>();
		open.add(startTile);
		while(!open.isEmpty())
		{
			current = getLowestCost(open);
			if(!current.equals(startTile) && !current.equals(endTile))
			{
				sr.begin(ShapeType.Filled);
				sr.setColor(Color.GRAY);
				sr.rect(current.x+(tileSize*current.x) + Xmargin, current.y+(tileSize*current.y) + Ymargin, tileSize, tileSize);
				sr.end();
				batch.begin();
				font.setColor(Color.BLACK);
				int xOffset = 3;
				if(grid[current.x][current.y].isTele)
					xOffset = 0;
				font.draw(batch, grid[current.x][current.y].getWeight(), current.x+(tileSize*current.x) + xOffset + Xmargin, current.y+(tileSize*current.y) - 2 + tileSize + Ymargin);
				batch.end();
				if(current.isTele)
				{
					sr.begin(ShapeType.Filled);
					sr.rect(current.dest.x+(tileSize*current.dest.x) + Xmargin, current.dest.y+(tileSize*current.dest.y) + Ymargin, tileSize, tileSize);
					sr.end();
					batch.begin();
					font.setColor(Color.BLACK);
					if(grid[current.dest.x][current.dest.y].isTele)
						xOffset = 0;
					font.draw(batch, grid[current.dest.x][current.dest.y].getWeight(), current.dest.x+(tileSize*current.dest.x) + xOffset + Xmargin, current.dest.y+(tileSize*current.dest.y) - 2 + tileSize + Ymargin);
					batch.end();
				}
			}
			open.remove(current);
			closed.add(current);
			if(current.isTele)
			{
				current.dest.parent = current;
				current = current.dest;
				open.remove(current);
				closed.add(current);
			}
			if(current.equals(endTile) || (current.isTele && current.dest.equals(endTile)))
			{
				return;
			}
			if(current.x > 0)
			{
				Tile target = grid[current.x-1][current.y];
				if(!target.getWeight().equals("F")
						&& !closed.contains(target))
				{
					updateTile(target, current);
				}
			}
			if(current.x < xLen-1)
			{
				Tile target = grid[current.x+1][current.y];
				if(!target.getWeight().equals("F")
						&& !closed.contains(target))
				{
					updateTile(target, current);
				}
			}
			if(current.y > 0)
			{
				Tile target = grid[current.x][current.y-1];
				if(!target.getWeight().equals("F")
						&& !closed.contains(target))
				{
					updateTile(target, current);
				}
			}
			if(current.y < yLen-1)
			{
				Tile target = grid[current.x][current.y+1];
				if(!target.getWeight().equals("F")
						&& !closed.contains(target))
				{
					updateTile(target, current);
				}
			}
		}
		
	}

	
	public void drawPath(ShapeRenderer sr)
	{
		Tile current = endTile;
		while(current.parent != null)
		{
			sr.begin(ShapeType.Filled);
			sr.setColor(Color.ORANGE);
			sr.rectLine((current.x*(tileSize+1)+Xmargin) +9, (current.y*(tileSize+1)+Ymargin) +8, (current.parent.x*(tileSize+1)+Xmargin) +9, (current.parent.y*(tileSize+1)+Ymargin) +8, 3);
			sr.setColor(Color.YELLOW);
			sr.rect((current.x*(tileSize+1)+Xmargin) +5, (current.y*(tileSize+1)+Ymargin) +5, 7, 7);
			sr.rect((current.parent.x*(tileSize+1)+Xmargin) +5, (current.parent.y*(tileSize+1)+Ymargin) +5, 7, 7);
			sr.end();
			if(current.parent.equals(current))
				break;
			else
				current = current.parent;
		}
	}
	
	
	
	
	private Tile getLowestCost(ArrayList<Tile> open)
	{
		if(open.isEmpty())return null;
		Tile lowest = open.get(0);
		for(Tile t: open)
		{
			if(t.f_cost < lowest.f_cost)
				lowest = t;
		}
		return lowest;
	}
	private void updateTile(Tile target, Tile current)
	{
		int tempG;
		int weight;
		if(!target.isTele)
		{
			weight = Integer.parseInt(target.getWeight());
		}
		else
		{
			weight = 0;
		}
		if(target.parent != null)
		{
			tempG = target.parent.g_cost + weight;
		}
		else
		{
			tempG = weight;
		}
		if(target.g_cost > tempG || target.g_cost == -1)
		{
			target.g_cost = tempG;
			target.parent = current;
		}
		target.f_cost = target.g_cost;
		if(!open.contains(target))
		{
			open.add(target);
		}
	}
	private void resetGrid()
	{
		for(int x = 0; x < xLen; x++)
		{
			for(int y = 0; y < yLen; y++)
			{
				grid[x][y].f_cost = -1;
				grid[x][y].g_cost = -1;
				grid[x][y].parent = null;
			}
		}
	}
	
	
	
	public int getStartX() {
		return startX;
	}
	public void setStartX(int startX) {
		this.startX = startX;
		this.startTile = grid[startX][startY];
		resetGrid();
	}
	public int getStartY() {
		return startY;
	}
	public void setStartY(int startY) {
		this.startY = startY;
		this.startTile = grid[startX][startY];
		resetGrid();
	}
	public int getEndX() {
		return endX;
	}
	public void setEndX(int endX) {
		this.endX = endX;
		this.endTile = grid[endX][endY];
		resetGrid();
	}
	public int getEndY() {
		return endY;
	}
	public void setEndY(int endY) {
		this.endY = endY;
		this.endTile = grid[endX][endY];
		resetGrid();
	}

}
