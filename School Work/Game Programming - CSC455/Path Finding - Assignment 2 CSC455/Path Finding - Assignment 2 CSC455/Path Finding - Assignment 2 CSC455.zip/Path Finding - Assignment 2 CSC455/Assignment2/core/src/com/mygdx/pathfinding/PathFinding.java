package com.mygdx.pathfinding;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;

public class PathFinding extends ApplicationAdapter {
	SpriteBatch batch;
	BitmapFont font;
	ShapeRenderer sr;
	Texture img;
	Grid grid;
	boolean changeStart;
	boolean changeEnd;
	
	@Override
	public void create () {
		batch = new SpriteBatch();
		font = new BitmapFont();
		sr = new ShapeRenderer();
		//grid = new Grid(100,100);
		grid = new Grid("Grid2");
		changeStart = false;
		changeEnd = false;
	}

	@Override
	public void render () {
		Gdx.gl.glClearColor(1, 1, 1, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		grid.draw(sr, batch, font);
		checkInputs();
		checkBounds();
		grid.findPath(sr,batch,font);
		grid.drawPath(sr);
		drawBottomBar(sr,batch,font);
	}
	
	public void checkInputs()
	{
		if(Gdx.input.isKeyPressed(Input.Keys.LEFT)){grid.Xmargin += -5;}
		if(Gdx.input.isKeyPressed(Input.Keys.RIGHT)){grid.Xmargin += 5;}
		if(Gdx.input.isKeyPressed(Input.Keys.UP)){grid.Ymargin += 5;}
		if(Gdx.input.isKeyPressed(Input.Keys.DOWN)){grid.Ymargin += -5;}
		if(Gdx.input.justTouched())
		{
			int mouseX = Gdx.input.getX();
			int mouseY = 600 - Gdx.input.getY();
			int x = ((mouseX - grid.Xmargin))/(Grid.tileSize +1);
			int y = ((mouseY - grid.Ymargin))/(Grid.tileSize +1);
			if(changeEnd)
			{
				if(x >= 0 &&  x < grid.xLen && y >= 0 &&  y < grid.yLen
						&& !grid.grid[x][y].getWeight().equals("F"))
				{
					grid.setEndX(x);
					grid.setEndY(y);
					changeEnd = false;
				}
			}
			else if(changeStart)
			{
				if(x >= 0 &&  x < grid.xLen && y >= 0 &&  y < grid.yLen
						&& !grid.grid[x][y].getWeight().equals("F"))
				{
					grid.setStartX(x);
					grid.setStartY(y);
					changeStart = false;
				}
			}
			else
			{
				if(mouseX > 0 && mouseX < 100
						&& mouseY > 0 && mouseY < 25)
				{
					changeStart = true;
					changeEnd = false;
				}
				else if(mouseX > 500 && mouseX < 600
						&& mouseY > 0 && mouseY < 25)
				{
					changeEnd = true;
					changeStart = false;
				}
			}
		}
	}
	public void checkBounds()
	{
		if(grid.Xmargin*-1 > grid.xLen*Grid.tileSize)grid.Xmargin = grid.xLen*Grid.tileSize*-1;
		if(grid.Xmargin > 590)grid.Xmargin = 590;
		if(grid.Ymargin*-1 > grid.yLen*Grid.tileSize -30)grid.Ymargin = grid.yLen*Grid.tileSize*-1 +30;
		if(grid.Ymargin > 590)grid.Ymargin = 590;
	}
	
	private void drawBottomBar(ShapeRenderer sr, SpriteBatch batch, BitmapFont font)
	{
		sr.begin(ShapeType.Filled);
		sr.setColor(Color.VIOLET);
		sr.rect(0, 0, 600, 25);
		if(changeStart)
			sr.setColor(Color.BLACK);
		else
			sr.setColor(Color.GREEN);
		sr.rect(0, 0, 100, 25);
		if(changeEnd)
			sr.setColor(Color.BLACK);
		else
			sr.setColor(Color.CYAN);
		sr.rect(500, 0, 100, 25);
		sr.end();
		
		batch.begin();
		font.setColor(Color.BLACK);
		font.draw(batch, "<-- Click Here to choose start tile. Or here for the end tile. -->", 107, 20);
		if(changeStart)
			font.setColor(Color.WHITE);
		else
			font.setColor(Color.BLACK);
		font.draw(batch, "START", 25, 17);
		if(changeEnd)
			font.setColor(Color.WHITE);
		else
			font.setColor(Color.BLACK);
		font.draw(batch, "END", 535, 17);
		batch.end();
	}
}
